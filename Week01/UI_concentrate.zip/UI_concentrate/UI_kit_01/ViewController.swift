//
//  ViewController.swift
//  UI_kit_01
//
//  Created by vlm on 2020/03/19.
//  Copyright © 2020 vlm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

